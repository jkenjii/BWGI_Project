class TaskStrategy:
    def executar(self):
        pass
